/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package farhad.rddha.Controller;

import static farhad.rddha.Controller.MainController.MyTab;
import javafx.fxml.Initializable;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;

public class playertabcontroller implements Initializable {

    @FXML public static Label lbl2;
    @FXML public static Button btn2;
    
    
    @Override
    public void initialize(URL location, ResourceBundle resources) {

    }
    
    @FXML private void bt2_pressed(ActionEvent event){
        
        
    }

}